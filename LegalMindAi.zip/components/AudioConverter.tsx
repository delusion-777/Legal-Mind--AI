import React, { useState } from 'react';
import axios from 'axios';

const App: React.FC = () => {
  const [text, setText] = useState('');
  const [targetLang, setTargetLang] = useState('es'); // Default to Spanish
  const [voice, setVoice] = useState('es-ES'); // Default voice for Spanish
  const [playbackSpeed, setPlaybackSpeed] = useState(1);
  const [audioUrl, setAudioUrl] = useState<string>('');
  const [loading, setLoading] = useState(false);

  const handleTranslateAndTTS = async () => {
    setLoading(true);
    try {
      // 1. Translate
      const translationResponse = await axios.post('/translate', { text, targetLang });
      const translatedText = translationResponse.data.translatedText;

      // 2. TTS
      const ttsResponse = await axios.post(
        '/tts',
        { translatedText, voice },
        { responseType: 'blob' }
      );
      const audioBlob = new Blob([ttsResponse.data], { type: 'audio/mpeg' });

      // 3. Prepare FormData for audio processing
      const formData = new FormData();
      formData.append('audio', audioBlob, 'audio.mp3');
      formData.append('speed', playbackSpeed.toString());

      // 4. Send to backend for speed adjustment
      const processedAudioResponse = await axios.post('/audio/process', formData, {
        responseType: 'blob',
        headers: { 'Content-Type': 'multipart/form-data' },
      });

      const processedAudioUrl = URL.createObjectURL(processedAudioResponse.data);
      setAudioUrl(processedAudioUrl);
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-xl mx-auto p-4 space-y-4">
      <textarea
        className="w-full border border-gray-300 rounded p-2 resize-none"
        rows={5}
        placeholder="Enter text to translate and convert to speech"
        value={text}
        onChange={(e) => setText(e.target.value)}
        aria-label="Text input"
      />

      <div className="flex gap-2 flex-wrap">
        <label htmlFor="targetLang" className="sr-only">Target Language</label>
        <select
          id="targetLang"
          value={targetLang}
          onChange={(e) => setTargetLang(e.target.value)}
          className="border border-gray-300 rounded p-2 flex-grow"
          aria-label="Select target language"
        >
          <option value="es">Spanish</option>
          <option value="fr">French</option>
          <option value="de">German</option>
          {/* Add more language options as needed */}
        </select>

        <label htmlFor="voice" className="sr-only">Voice</label>
        <select
          id="voice"
          value={voice}
          onChange={(e) => setVoice(e.target.value)}
          className="border border-gray-300 rounded p-2 flex-grow"
          aria-label="Select voice"
        >
          <option value="es-ES">Spanish (es-ES)</option>
          <option value="fr-FR">French (fr-FR)</option>
          <option value="de-DE">German (de-DE)</option>
          {/* Add more voice options as needed */}
        </select>

        <label htmlFor="playbackSpeed" className="sr-only">Playback speed</label>
        <select
          id="playbackSpeed"
          value={playbackSpeed}
          onChange={(e) => setPlaybackSpeed(Number(e.target.value))}
          className="border border-gray-300 rounded p-2"
          aria-label="Select playback speed"
        >
          <option value={0.5}>0.5x</option>
          <option value={1}>1x</option>
          <option value={1.5}>1.5x</option>
          <option value={2}>2x</option>
          {/* Add more playback speed options as needed */}
        </select>
      </div>

      <button
        onClick={handleTranslateAndTTS}
        disabled={loading || !text.trim()}
        className={`w-full p-2 rounded text-white font-semibold ${
          loading || !text.trim() ? 'bg-gray-400 cursor-not-allowed' : 'bg-blue-600 hover:bg-blue-700'
        }`}
        aria-label="Generate audio button"
      >
        {loading ? 'Processing...' : 'Generate Audio'}
      </button>

      {audioUrl && (
        <audio
          src={audioUrl}
          controls
          className="w-full mt-4"
          aria-label="Generated audio playback"
        >
          Your browser does not support the audio element.
        </audio>
      )}
    </div>
  );
};

export default App;