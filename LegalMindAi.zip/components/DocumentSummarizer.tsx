import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { Alert, AlertDescription } from './ui/alert';
import { BookOpen, Upload, FileText, Clock, Users, AlertTriangle, CheckCircle, Globe, Languages, Share2, Copy, Download, ExternalLink, Loader2 } from 'lucide-react';

interface SummaryResult {
  executiveSummary: string;
  keyPoints: string[];
  documentInfo: {
    type: string;
    language: string;
    wordCount: number;
    complexity: string;
  };
  detailedAnalysis: {
    parties: string[];
    obligations: string[];
    risks: string[];
    recommendations: string[];
  };
  processedAt: string;
}

interface SharedDocument {
  name: string;
  text: string;
  analysisResults?: any;
  timestamp: Date;
}

interface DocumentSummarizerProps {
  sharedDocument: SharedDocument | null;
}

const SUPPORTED_LANGUAGES = [
  { code: 'en', name: 'English', flag: '🇺🇸', nativeName: 'English' },
  { code: 'hi', name: 'Hindi', flag: '🇮🇳', nativeName: 'हिंदी' },
  // Add more languages as needed
];

const apiUrl = 'http://localhost:4000/api/summarize-document';

export function DocumentSummarizer({ sharedDocument }: DocumentSummarizerProps) {
  const [summaryLanguage, setSummaryLanguage] = useState<string>('en');
  const [summaryType, setSummaryType] = useState<string>('comprehensive');
  const [documentText, setDocumentText] = useState<string>('');
  const [summarizing, setSummarizing] = useState(false);
  const [summaryProgress, setSummaryProgress] = useState(0);
  const [results, setResults] = useState<SummaryResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (sharedDocument) {
      setDocumentText(sharedDocument.text);
    }
  }, [sharedDocument]);

  const generateSummary = async () => {
    if (!documentText.trim() && !sharedDocument) {
      setError('Please enter document text or use a document from the analyzer');
      return;
    }

    setSummarizing(true);
    setSummaryProgress(0);
    setError(null);

    try {
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          text: documentText || sharedDocument?.text,
          language: summaryLanguage,
          summaryType,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to generate summary');
      }

      const data: SummaryResult = await response.json();
      setResults(data);

    } catch (err) {
      console.error('Summarization error:', err);
      setError(err instanceof Error ? err.message : 'Failed to generate summary');
    } finally {
      setSummarizing(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-white/60 backdrop-blur-sm border-slate-200/50 shadow-sm">
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center gap-2 text-slate-800">
            <BookOpen className="h-5 w-5 text-slate-600" />
            Document Summarizer
          </CardTitle>
          <CardDescription className="text-slate-600">
            Generate summaries of legal documents in multiple languages with AI-powered analysis.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Document Text Input */}
          <div className="space-y-3">
            <Label htmlFor="document-text">Document Text</Label>
            <textarea
              id="document-text"
              value={documentText}
              onChange={(e) => setDocumentText(e.target.value)}
              className="w-full h-40 p-2 border border-slate-300 rounded-lg"
              placeholder="Enter or paste document text here..."
            />
          </div>

          {/* Summary Language Selection */}
          <div className="space-y-3">
            <Label htmlFor="summary-language">Summary Language</Label>
            <Select value={summaryLanguage} onValueChange={setSummaryLanguage}>
              <SelectTrigger className="bg-white border-slate-300">
                <SelectValue placeholder="Select summary language" />
              </SelectTrigger>
              <SelectContent className="bg-white border-slate-300">
                {SUPPORTED_LANGUAGES.map((lang) => (
                  <SelectItem key={lang.code} value={lang.code}>
                    <div className="flex items-center gap-2">
                      <span>{lang.flag}</span>
                      <span>{lang.name}</span>
                      <span className="text-sm text-slate-500">({lang.nativeName})</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Summary Type Selection */}
          <div className="space-y-3">
            <Label htmlFor="summary-type">Summary Type</Label>
            <Select value={summaryType} onValueChange={setSummaryType}>
              <SelectTrigger className="bg-white border-slate-300">
                <SelectValue placeholder="Select summary type" />
              </SelectTrigger>
              <SelectContent className="bg-white border-slate-300">
                <SelectItem value="brief">Brief Summary</SelectItem>
                <SelectItem value="comprehensive">Comprehensive Summary</SelectItem>
                <SelectItem value="detailed">Detailed Analysis</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Generate Summary Button */}
          <Button
            onClick={generateSummary}
            disabled={summarizing || (!documentText.trim() && !sharedDocument)}
            className="w-full bg-slate-800 hover:bg-slate-900 text-white"
          >
            {summarizing ? (
              <div className="flex items-center gap-2">
                <Loader2 className="h-4 w-4 animate-spin" />
                Generating Summary...
              </div>
            ) : (
              'Generate Summary'
            )}
          </Button>

          {/* Progress Indicator */}
          {summarizing && (
            <div className="space-y-3">
              <Progress value={summaryProgress} className="w-full h-2" />
              <p className="text-sm text-slate-600 text-center">
                Analyzing document and generating summary...
              </p>
            </div>
          )}

          {/* Summary Results */}
          {results && (
            <div className="space-y-6">
              <Card className="bg-white/60 backdrop-blur-sm border-slate-200/50 shadow-sm">
                <CardHeader className="pb-4">
                  <CardTitle className="flex items-center gap-2 text-slate-800">
                    <CheckCircle className="h-5 w-5 text-green-500" />
                    Summary Generated
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <Label className="text-sm text-slate-700">Executive Summary</Label>
                      <p className="text-sm text-slate-600">{results.executiveSummary}</p>
                    </div>
                    <Separator className="my-4 bg-slate-200" />
                    <div>
                      <Label className="text-sm text-slate-700">Key Points</Label>
                      <ul className="list-disc list-inside text-sm text-slate-600">
                        {results.keyPoints.map((point, index) => (
                          <li key={index}>{point}</li>
                        ))}
                      </ul>
                    </div>
                    <Separator className="my-4 bg-slate-200" />
                    <div>
                      <Label className="text-sm text-slate-700">Document Information</Label>
                      <div className="grid grid-cols-2 gap-4 text-sm text-slate-600">
                        <p><strong>Type:</strong> {results.documentInfo.type}</p>
                        <p><strong>Language:</strong> {results.documentInfo.language}</p>
                        <p><strong>Word Count:</strong> {results.documentInfo.wordCount}</p>
                        <p><strong>Complexity:</strong> {results.documentInfo.complexity}</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Detailed Analysis */}
              <Card className="bg-white/60 backdrop-blur-sm border-slate-200/50 shadow-sm">
                <CardHeader className="pb-4">
                  <CardTitle className="flex items-center gap-2 text-slate-800">
                    <AlertTriangle className="h-5 w-5 text-yellow-500" />
                    Detailed Analysis
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <Label className="text-sm text-slate-700">Parties Involved</Label>
                      <ul className="list-disc list-inside text-sm text-slate-600">
                        {results.detailedAnalysis.parties.map((party, index) => (
                          <li key={index}>{party}</li>
                        ))}
                      </ul>
                    </div>
                    <div>
                      <Label className="text-sm text-slate-700">Obligations</Label>
                      <ul className="list-disc list-inside text-sm text-slate-600">
                        {results.detailedAnalysis.obligations.map((obligation, index) => (
                          <li key={index}>{obligation}</li>
                        ))}
                      </ul>
                    </div>
                    <div>
                      <Label className="text-sm text-slate-700">Risks</Label>
                      <ul className="list-disc list-inside text-sm text-slate-600">
                        {results.detailedAnalysis.risks.map((risk, index) => (
                          <li key={index}>{risk}</li>
                        ))}
                      </ul>
                    </div>
                    <div>
                      <Label className="text-sm text-slate-700">Recommendations</Label>
                      <ul className="list-disc list-inside text-sm text-slate-600">
                        {results.detailedAnalysis.recommendations.map((recommendation, index) => (
                          <li key={index}>{recommendation}</li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}