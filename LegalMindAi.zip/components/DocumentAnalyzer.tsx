import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Progress } from './ui/progress';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { Alert, AlertDescription } from './ui/alert';
import { FileText, Upload, X, Users, Clock, DollarSign, AlertTriangle, FileCheck, TrendingUp, Lightbulb, CheckCircle, Globe, Languages, Target, ShieldCheck } from 'lucide-react';

interface AnalysisResult {
  documentType: {
    category: string;
    subcategory: string;
    confidence: number;
    jurisdiction: string;
  };
  extractedText: string;
  parties: Array<{
    name: string;
    type: 'individual' | 'corporation' | 'government' | 'partnership';
    role: string;
    address?: string;
  }>;
  keyDates: Array<{
    date: string;
    description: string;
    type: 'deadline' | 'effective' | 'expiration' | 'milestone';
    importance: 'critical' | 'high' | 'medium' | 'low';
  }>;
  financialTerms: Array<{
    amount: string;
    currency: string;
    type: 'payment' | 'penalty' | 'deposit' | 'fee';
    frequency?: string;
    conditions?: string;
  }>;
  obligations: Array<{
    party: string;
    obligation: string;
    deadline?: string;
    penalty?: string;
    status: 'pending' | 'completed' | 'overdue';
  }>;
  riskFactors: Array<{
    type: 'high' | 'medium' | 'low';
    description: string;
    impact: string;
    mitigation?: string;
  }>;
  complianceItems: Array<{
    requirement: string;
    status: 'compliant' | 'non-compliant' | 'unclear';
    details: string;
  }>;
  improvements: Array<{
    category: 'Language Clarity' | 'Legal Compliance' | 'Risk Mitigation' | 'Structure' | 'Terms & Conditions';
    priority: 'critical' | 'high' | 'medium' | 'low';
    issue: string;
    suggestion: string;
    impact: string;
    example?: string;
  }>;
  overallScore: {
    clarity: number;
    completeness: number;
    riskLevel: number;
    compliance: number;
  };
}

interface SharedDocument {
  name: string;
  text: string;
  analysisResults: AnalysisResult;
  timestamp: Date;
}

interface DocumentAnalyzerProps {
  onDocumentAnalyzed: (documentData: SharedDocument) => void;
}

const SUPPORTED_LANGUAGES = [
  { code: 'en', name: 'English', flag: '🇺🇸', nativeName: 'English' },
  { code: 'hi', name: 'Hindi', flag: '🇮🇳', nativeName: 'हिंदी' },
  // Add more languages as needed
];

const apiUrl = 'http://localhost:4000/api/analyze-document';

export function DocumentAnalyzer({ onDocumentAnalyzed }: DocumentAnalyzerProps) {
  const [file, setFile] = useState<File | null>(null);
  const [analysisLanguage, setAnalysisLanguage] = useState<string>('en');
  const [analyzing, setAnalyzing] = useState(false);
  const [analysisProgress, setAnalysisProgress] = useState(0);
  const [results, setResults] = useState<AnalysisResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = event.target.files?.[0];
    if (selectedFile) {
      setFile(selectedFile);
    }
  };

  const handleCancelFile = () => {
    setFile(null);
    setResults(null);
    // Reset the file input
    const fileInput = document.getElementById('file-upload') as HTMLInputElement;
    if (fileInput) {
      fileInput.value = '';
    }
  };

  const analyzeDocument = async () => {
    if (!file) return;

    setAnalyzing(true);
    setAnalysisProgress(0);
    setError(null);

    const formData = new FormData();
    formData.append('document', file);
    formData.append('language', analysisLanguage);

    try {
      const response = await fetch(apiUrl, {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        throw new Error('Failed to analyze document');
      }

      const analysisResult: AnalysisResult = await response.json();
      setResults(analysisResult);

      // Share document with summarizer
      const documentData: SharedDocument = {
        name: file.name,
        text: analysisResult.extractedText,
        analysisResults: analysisResult,
        timestamp: new Date(),
      };
      onDocumentAnalyzed(documentData);

    } catch (err) {
      console.error('Analysis error:', err);
      setError(err instanceof Error ? err.message : 'Failed to analyze document');
    } finally {
      setAnalyzing(false);
      setAnalysisProgress(0);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="bg-white/60 backdrop-blur-sm border-slate-200/50 shadow-sm">
        <CardHeader className="pb-4">
          <CardTitle className="flex items-center gap-2 text-slate-800">
            <FileText className="h-5 w-5 text-slate-600" />
            Enhanced Legal Document Analyzer
          </CardTitle>
          <CardDescription className="text-slate-600">
            Upload legal documents for comprehensive AI analysis with multilingual support and detailed improvement suggestions.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Document Upload */}
          <div className="space-y-3">
            <Label htmlFor="file-upload" className="text-slate-700">Upload Legal Document</Label>
            <div className="border-2 border-dashed border-slate-300 rounded-xl p-8 text-center bg-slate-50/50 hover:bg-slate-50 transition-colors">
              <Upload className="h-12 w-12 text-slate-400 mx-auto mb-4" />
              <div className="space-y-2">
                <Input
                  id="file-upload"
                  type="file"
                  accept=".txt,.pdf,.doc,.docx"
                  onChange={handleFileUpload}
                  className="max-w-xs mx-auto bg-white border-slate-300"
                />
                <p className="text-sm text-slate-500">
                  Supports PDF, DOC, DOCX, and TXT files (max 50MB)
                </p>
              </div>
            </div>
            {file && (
              <div className="flex items-center justify-between p-4 bg-slate-100 border border-slate-200 rounded-xl">
                <div className="flex items-center gap-3">
                  <FileText className="h-5 w-5 text-slate-600" />
                  <div className="flex flex-col">
                    <span className="font-medium text-slate-800">{file.name}</span>
                    <span className="text-sm text-slate-500">{(file.size / 1024).toFixed(1)} KB</span>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="secondary" className="bg-green-100 text-green-800 border-green-200">
                    Ready for analysis
                  </Badge>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={handleCancelFile}
                    className="h-8 w-8 p-0 border-slate-300 hover:bg-red-50 hover:border-red-300"
                  >
                    <X className="h-4 w-4 text-slate-600 hover:text-red-600" />
                  </Button>
                </div>
              </div>
            )}
          </div>

          {/* Analysis Language Selection */}
          <div className="space-y-3">
            <Label htmlFor="analysis-language" className="text-slate-700 flex items-center gap-2">
              <Globe className="h-4 w-4" />
              Analysis Language
            </Label>
            <Select value={analysisLanguage} onValueChange={setAnalysisLanguage}>
              <SelectTrigger className="bg-white border-slate-300">
                <SelectValue placeholder="Select analysis language" />
              </SelectTrigger>
              <SelectContent className="bg-white border-slate-300 max-h-60">
                {SUPPORTED_LANGUAGES.map((lang) => (
                  <SelectItem key={lang.code} value={lang.code}>
                    <div className="flex items-center gap-2">
                      <span>{lang.flag}</span>
                      <span>{lang.name}</span>
                      <span className="text-sm text-slate-500">({lang.nativeName})</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Analyze Button */}
          <Button
            onClick={analyzeDocument}
            disabled={!file || analyzing}
            className="w-full bg-slate-800 hover:bg-slate-900 text-white"
          >
            {analyzing ? 'Analyzing Document...' : 'Analyze Document with AI'}
          </Button>

          {/* Progress */}
          {analyzing && (
            <div className="space-y-3">
              <Progress value={analysisProgress} className="w-full h-2" />
              <p className="text-sm text-slate-600 text-center">
                Extracting entities, analyzing structure, and generating insights in {SUPPORTED_LANGUAGES.find(l => l.code === analysisLanguage)?.name}...
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Results */}
      {results && (
        <Card className="mt-6">
          <CardHeader>
            <CardTitle>Analysis Results</CardTitle>
            <CardDescription>
              Here's what the AI extracted from your document.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label>Document Type:</Label>
              <p>{results.documentType.category}</p>
            </div>
            <div>
              <Label>Language:</Label>
              <p>{analysisLanguage}</p>
            </div>
            <div>
              <Label>Word Count:</Label>
              <p>{results.extractedText.split(/\s+/).length}</p>
            </div>
            <div>
              <Label>Complexity:</Label>
              <p>Medium</p>
            </div>
            <Separator />

            <div>
              <Label>Parties:</Label>
              <ul className="list-disc list-inside">
                {results.parties.map((party, index) => (
                  <li key={index}>{party.name}</li>
                ))}
              </ul>
            </div>

            <div>
              <Label>Obligations:</Label>
              <ul className="list-disc list-inside">
                {results.obligations.map((item, index) => (
                  <li key={index}>{item.obligation}</li>
                ))}
              </ul>
            </div>

            <div>
              <Label>Risks:</Label>
              <ul className="list-disc list-inside">
                {results.riskFactors.map((item, index) => (
                  <li key={index}>{item.description}</li>
                ))}
              </ul>
            </div>

            <div>
              <Label>Recommendations:</Label>
              <ul className="list-disc list-inside">
                {results.improvements.map((item, index) => (
                  <li key={index}>{item.suggestion}</li>
                ))}
              </ul>
            </div>

            <Separator />
            <div>
              <Label>Processed At:</Label>
              <p>{new Date().toLocaleString()}</p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}