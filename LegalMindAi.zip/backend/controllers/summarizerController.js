const openai = require('../config/openaiConfig');

const summarizeDocument = async (req, res) => {
  const { text } = req.body;

  try {
    const response = await openai.createChatCompletion({
      model: "gpt-4",
      messages: [
        { role: "system", content: "Summarize the following document:" },
        { role: "user", content: text },
      ],
    });

    const summary = response.data.choices[0].message.content;
    res.json({ summary });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Summarization failed' });
  }
};

module.exports = { summarizeDocument };