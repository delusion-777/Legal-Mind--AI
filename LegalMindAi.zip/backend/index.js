const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');

// Load .env variables
dotenv.config();

const app = express();
app.use(express.json());
app.use(cors());

// Import Routes
const chatbotRoutes = require('./routes/chatbot');
const analyzerRoutes = require('./routes/analyzer');
const summarizerRoutes = require('./routes/summarizer');
const ttsRoutes = require('./routes/tts');

// Mount Routes
app.use('/api/chat', chatbotRoutes);
app.use('/api/analyze', analyzerRoutes);
app.use('/api/summarize', summarizerRoutes);
app.use('/api/tts', ttsRoutes);

// Start Server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
});
