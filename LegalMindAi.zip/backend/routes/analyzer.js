const openai = require('../config/openaiConfig');

const analyzeDocument = async (req, res) => {
  const { text } = req.body;

  try {
    const response = await openai.createChatCompletion({
      model: "gpt-4",
      messages: [
        { role: "system", content: "Analyze the following document and provide insights:" },
        { role: "user", content: text },
      ],
    });

    const analysis = response.data.choices[0].message.content;
    res.json({ analysis });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Document analysis failed' });
  }
};

module.exports = { analyzeDocument };