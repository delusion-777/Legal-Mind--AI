const openai = require('../config/openaiConfig');

const summarizeDocument = async (req, res) => {
  const { text, apiProvider } = req.body;

  try {
    if (apiProvider === 'openai') {
      const response = await openai.createChatCompletion({
        model: "gpt-4",
        messages: [
          { role: "system", content: "Summarize the following document:" },
          { role: "user", content: text },
        ],
      });

      const summary = response.data.choices[0].message.content;
      res.json({ summary });
    } else if (apiProvider === 'elevenlabs') {
      // ElevenLabs summarization is not directly available, 
      // you may need to implement a custom summarization logic
      // or use a different API that provides summarization
      res.status(400).json({ error: 'ElevenLabs summarization is not supported' });
    } else {
      res.status(400).json({ error: 'Invalid API provider' });
    }
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Summarization failed' });
  }
};

module.exports = { summarizeDocument };