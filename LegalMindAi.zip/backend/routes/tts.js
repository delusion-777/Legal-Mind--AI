const { ElevenLabsClient } = require('elevenlabs');
require('dotenv').config();

const client = new ElevenLabsClient({
  apiKey: process.env.ELEVENLABS_API_KEY
});

const textToSpeech = async (req, res) => {
  const { text } = req.body;

  try {
    const audio = await client.generate({
      text: text,
      voice: 'Rachel', // or any voice supported
      model_id: 'eleven_monolingual_v1',
    });

    res.set("Content-Disposition", `attachment; filename="audio.mp3"`);
    res.set("Content-Type", "audio/mpeg");
    res.send(audio);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Text-to-Speech failed' });
  }
};

module.exports = { textToSpeech };